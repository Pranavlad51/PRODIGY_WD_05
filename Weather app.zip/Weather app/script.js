const apiKey = "aba7d4e4687c0f60a40eed699c15162a"; // OpenWeatherMap API key

async function getWeatherByCity() {
    const city = document.getElementById("city-input").value;
    if (!city) return alert("Please enter a city name!");

    const url = `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(city)}&appid=${apiKey}&units=metric`;

    try {
        const response = await fetch(url);
        if (!response.ok) throw new Error("City not found");
        const data = await response.json();
        displayWeather(data);
    } catch (error) {
        document.getElementById("weather-box").innerHTML = `<p>${error.message}</p>`;
    }
}

async function getWeatherByLocation() {
    if (!navigator.geolocation) {
        return alert("Geolocation is not supported by your browser.");
    }
    navigator.geolocation.getCurrentPosition(async (position) => {
        const { latitude, longitude } = position.coords;
        const url = `https://api.openweathermap.org/data/2.5/weather?lat=${latitude}&lon=${longitude}&appid=${apiKey}&units=metric`;

        try {
            const response = await fetch(url);
            if (!response.ok) throw new Error("Location not found");
            const data = await response.json();
            displayWeather(data);
        } catch (error) {
            document.getElementById("weather-box").innerHTML = `<p>${error.message}</p>`;
        }
    });
}

function displayWeather(data) {
    document.getElementById("weather-box").innerHTML = `
        <h2>${data.name}, ${data.sys.country}</h2>
        <p><b>${data.weather[0].main}</b> - ${data.weather[0].description}</p>
        <p>🌡 Temp: ${data.main.temp}°C</p>
        <p>💧 Humidity: ${data.main.humidity}%</p>
        <p>🌬 Wind: ${data.wind.speed} m/s</p>
    `;
}